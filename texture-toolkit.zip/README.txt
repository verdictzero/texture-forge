PROCEDURAL TEXTURE TOOLKIT
==========================

Four self-contained generators. Open any .html file in a browser — no install,
no build step, no network needed. Everything runs locally in the page.

Each one previews with a real-time GGX lit view (drag to move the light) and
exports a full PBR set as PNG, individually or all at once as a .zip.


panel-forge.html — Seamless riveted aircraft skin
-------------------------------------------------
Staggered panel bays with lap-joint steps, rivets (universal dome, flush
countersunk or mixed, optional double rows and field doubler patches),
three-layer chipping from paint through zinc-chromate primer to bare
aluminium, scratches, streaks and seam grime.

Tiles seamlessly in both axes.
Presets: weathered warbird, clean airliner, bare aluminium, derelict hulk.


street-forge.html — Asphalt and street layout
----------------------------------------------
Everything is dimensioned in real metres: tile size, stone size in mm, crack
cells, lane widths, dash cycles. Zooming out genuinely adds detail rather than
magnifying it, with texel-aware antialiasing and automatic aggregate LOD.

Surface: three grades of faceted crushed aggregate in bitumen, fines,
ravelling, alligator and long cracks, sealant, potholes, patches, paving
joints, wheel rutting and polish, oil, dust, wetness and standing water.

Street pieces: plain, full cross-section, edge / centre / lane lines, stop bar,
crosswalk (4 styles), turn arrows, 4-way intersection, parking bays. The
asphalt always tiles both ways so every piece butts against every other; only
the markings decide whether a piece repeats. Dash cycles snap to whole repeats.

Kerb and footway: gutter pan, kerb, footway with crossfall, control and
expansion joints, broom finish, slab settlement, kerb paint, dirt verge, and a
full concrete distress stack (spalling, crazing, cracked slabs, popouts,
efflorescence, moss).

Presets: close-up 1 m, highway 12 m, backroad, wet night, kerbside street,
kerbside wrecked, intersection.


elevation-forge.html — American house front elevation
------------------------------------------------------
A composed facade rather than a tiling texture, dimensioned in feet. Output is
non-square at uniform texel density and carries an alpha channel, so a gable
front gives you a real cut-out silhouette to drop onto a plane.

Cladding: clapboard, vinyl, board and batten, wood shingle, brick, stucco,
stone veneer. Openings: double-hung sashes with configurable lites, casing,
projecting sills, shutters, and six-panel / four-panel / half-light / flush
doors with transoms, hoods and steps. Full eave assembly with a K-style gutter,
fascia, vented soffit and a connected downspout.

Weathering: sun fade, peeling paint through undercoat to bare wood, drip
streaks, splash-back, mildew, nail rust, rot and overall grunge.
Abandonment: boarded windows (OSB, plywood or salvaged planks), broken glass,
graffiti, climbing vines, missing siding exposing felt and studs.

Presets: colonial, bungalow, brick rowhouse, vinyl tract, abandoned,
derelict shell.


asphalt-forge.html — superseded
--------------------------------
The earlier asphalt-only tool, kept only in case you have work keyed to it.
street-forge.html replaces it and does everything this one does.


EXPORTED MAPS
-------------
Base colour, normal, roughness, metallic, AO, height, ORM (packed), plus
per-tool extras: markings alpha decal (street), material ID / emissive /
opacity (elevation). Each zip also contains a 16-bit height PNG and a readme
giving the real-world size of the tile so displacement comes out true to life.

Notes worth knowing:

- Metallic is flat black in the street tool by design — asphalt, water and road
  paint are all dielectric. In the elevation tool glass is deliberately set
  metallic as a cheat so an opaque pane reads as glass; set it to 0 if your
  engine does real transparent glass.

- Use the 16-bit height for displacement wherever the texture contains a large
  step (a kerb, a window reveal). At 8 bits those steps eat most of the range
  and the fine surface bands.

- Heavier resolutions build on demand: dragging a slider shows a small preview
  and releasing rebuilds at full size. Exports refuse to run off a preview.

- If a download does not start, click the orange Save button that appears next
  to it — that path cannot be blocked by the browser.
